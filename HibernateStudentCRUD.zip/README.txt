Java Experiment 9 - Hibernate CRUD Application

Entity: Student (id, name, age)
Database: MySQL (studentdb)

Instructions:
- Import this as a Java or Maven project.
- Ensure MySQL is running and `studentdb` exists.
- Run Main.java to test CRUD operations.

Files:
- Student.java
- HibernateUtil.java
- Main.java
- hibernate.cfg.xml
